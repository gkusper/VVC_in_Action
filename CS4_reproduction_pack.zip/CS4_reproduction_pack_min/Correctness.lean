import C1
import L0

theorem c1_correct (a : List Int) (x : Int) :
    FirstIndexSpec a x (C1 a x) := by
  induction a with
  | nil => simp [C1, FirstIndexSpec]
  | cons h t ih =>
    by_cases hx : h = x
    · subst h
      simp [C1, FirstIndexSpec]
    · simp only [C1, beq_iff_eq, hx, ↓reduceIte]
      cases hr : C1 t x with
      | none =>
        simp only [Option.map_none]
        rw [hr] at ih
        intro j hj
        cases j with
        | zero => simpa using hx
        | succ k =>
          simpa using ih k (by simpa using hj)
      | some i =>
        simp only [Option.map_some]
        rw [hr] at ih
        obtain ⟨hb, hv, hf⟩ := ih
        refine ⟨by simpa using hb, by simpa using hv, ?_⟩
        intro j hj
        cases j with
        | zero => simpa using hx
        | succ k => simpa using hf k (by omega)

theorem c1_universally_correct :
    ∀ a x, FirstIndexSpec a x (C1 a x) := c1_correct

#print axioms c1_universally_correct
