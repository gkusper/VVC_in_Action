param([string]$LeanExe = '', [string]$OutputDirectory = '')
$ErrorActionPreference = 'Stop'
if (!$LeanExe) { $LeanExe = (Get-Command lean -ErrorAction Stop).Source }
$LeanExe = (Resolve-Path -LiteralPath $LeanExe).Path
if (!$OutputDirectory) { $OutputDirectory = Join-Path $PSScriptRoot ('replay/' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffffffZ')) }
New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null
$OutputDirectory = (Resolve-Path -LiteralPath $OutputDirectory).Path
$encoding = [Text.UTF8Encoding]::new($false)
$log = Join-Path $OutputDirectory 'verification.log'
$sources = @'
[
  {
    "name": "AnyIndexSpec.lean",
    "sha256": "b2eaff89f9595ffdda7d738493d02b494362e502179b43cb141c08e61d1dd36a"
  },
  {
    "name": "C0.lean",
    "sha256": "a95c74bba178d3e58d949d907f223537bf4b8f02c04e1d39e3b46b44123ea759"
  },
  {
    "name": "C1.lean",
    "sha256": "218341139fbca25a949f40e4a63e9f41100c88af3af812064b84743d790c613d"
  },
  {
    "name": "L0.lean",
    "sha256": "a44c2f0c2e65e36b51fde82a5b5dc83f8c25d1773360524175a53640e4a5260e"
  },
  {
    "name": "T0.lean",
    "sha256": "6faa579674259b7d507c94424ccdf8566d8673f920f977f9fc846cce67380ce4"
  },
  {
    "name": "TestsC0.lean",
    "sha256": "1b0b50adb9a7abbdd9d47f60e2f8945a7724b8b72d62b516d7b263c5bbfcb733"
  },
  {
    "name": "TestsC1.lean",
    "sha256": "a0cb1efd633ac9e56641d5916c8b6afce6cd9afcc5cf03fd306b80f5758a9c49"
  },
  {
    "name": "InitialViolation.lean",
    "sha256": "7324203379bfc7e3ad2998cab266a95ed6a0a7fe935f3f82282cf421dcbb4687"
  },
  {
    "name": "Correctness.lean",
    "sha256": "3436d9fb03ccc7ef511446f546a076a89bd4912682aaeb58579e5edb6b177578"
  },
  {
    "name": "ConcreteContrast.lean",
    "sha256": "b317017dc64e6c5f0a3c56fdafd98972f40db5775d90619d386f38bc1fe78605"
  },
  {
    "name": "SpecificationStrength.lean",
    "sha256": "3fefa71e8947178d1b4eb68e72b2f6a73117506c0fe3a00b7c816a597bbbea3f"
  },
  {
    "name": "WeakCorrectness.lean",
    "sha256": "d1b6b6d4e10f4fc7cf5ded7b7271b657b0d1edaf7086083a2886696bcaecf1c3"
  },
  {
    "name": "AtMostOneOccurrence.lean",
    "sha256": "ac6dd480836a5da366ad02bff360038258ba645ce21be71c0eafa19a57216f04"
  },
  {
    "name": "DomainWitness.lean",
    "sha256": "c352558d972ad54bb648f3b2bcbff746b416e03f99244dabbeb521338d754408"
  },
  {
    "name": "RestrictedCorrectness.lean",
    "sha256": "48aa76a06d16c322c410abbb7a6ebc4aeeec59abfdfb5f5ec5e8af7c951f8958"
  }
]
'@ | ConvertFrom-Json
$steps = @'
[
  {
    "arguments": [
      "-o",
      "C0.olean",
      "C0.lean"
    ],
    "tests": false,
    "contains": []
  },
  {
    "arguments": [
      "-o",
      "C1.olean",
      "C1.lean"
    ],
    "tests": false,
    "contains": []
  },
  {
    "arguments": [
      "-o",
      "T0.olean",
      "T0.lean"
    ],
    "tests": false,
    "contains": []
  },
  {
    "arguments": [
      "-o",
      "L0.olean",
      "L0.lean"
    ],
    "tests": false,
    "contains": []
  },
  {
    "arguments": [
      "-o",
      "AnyIndexSpec.olean",
      "AnyIndexSpec.lean"
    ],
    "tests": false,
    "contains": []
  },
  {
    "arguments": [
      "-o",
      "AtMostOneOccurrence.olean",
      "AtMostOneOccurrence.lean"
    ],
    "tests": false,
    "contains": []
  },
  {
    "arguments": [
      "--run",
      "TestsC0.lean"
    ],
    "tests": true,
    "contains": []
  },
  {
    "arguments": [
      "-o",
      "InitialViolation.olean",
      "InitialViolation.lean"
    ],
    "tests": false,
    "contains": [
      "c0_not_universally_correct"
    ]
  },
  {
    "arguments": [
      "--run",
      "TestsC1.lean"
    ],
    "tests": true,
    "contains": []
  },
  {
    "arguments": [
      "-o",
      "Correctness.olean",
      "Correctness.lean"
    ],
    "tests": false,
    "contains": [
      "c1_universally_correct"
    ]
  },
  {
    "arguments": [
      "-o",
      "WeakCorrectness.olean",
      "WeakCorrectness.lean"
    ],
    "tests": false,
    "contains": [
      "c0_weak_universally_correct"
    ]
  },
  {
    "arguments": [
      "-o",
      "ConcreteContrast.olean",
      "ConcreteContrast.lean"
    ],
    "tests": false,
    "contains": [
      "cs3_duplicate_weak",
      "cs3_duplicate_not_full"
    ]
  },
  {
    "arguments": [
      "-o",
      "SpecificationStrength.olean",
      "SpecificationStrength.lean"
    ],
    "tests": false,
    "contains": [
      "full_implies_weak",
      "weak_does_not_imply_full"
    ]
  },
  {
    "arguments": [
      "-o",
      "RestrictedCorrectness.olean",
      "RestrictedCorrectness.lean"
    ],
    "tests": false,
    "contains": [
      "c0_restricted_universally_correct"
    ]
  },
  {
    "arguments": [
      "-o",
      "DomainWitness.olean",
      "DomainWitness.lean"
    ],
    "tests": false,
    "contains": [
      "duplicate_target_excluded",
      "all_seven_T0_inputs_admitted"
    ]
  }
]
'@ | ConvertFrom-Json
foreach ($source in $sources) {
  $path = Join-Path $PSScriptRoot $source.name
  if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $source.sha256) { throw "Source hash differs: $($source.name)" }
  Copy-Item -LiteralPath $path -Destination $OutputDirectory
}
function Invoke-Lean([string[]]$Arguments) {
  $info = [Diagnostics.ProcessStartInfo]::new()
  $info.FileName = $LeanExe
  $info.WorkingDirectory = $OutputDirectory
  $info.UseShellExecute = $false
  $info.CreateNoWindow = $true
  $info.RedirectStandardOutput = $true
  $info.RedirectStandardError = $true
  foreach ($item in $Arguments) { $info.ArgumentList.Add($item) }
  $process = [Diagnostics.Process]::new()
  $process.StartInfo = $info
  if (!$process.Start()) { throw 'Cannot start Lean' }
  $outTask = $process.StandardOutput.ReadToEndAsync()
  $errTask = $process.StandardError.ReadToEndAsync()
  $process.WaitForExit()
  $stdout = $outTask.GetAwaiter().GetResult()
  $stderr = $errTask.GetAwaiter().GetResult()
  $code = $process.ExitCode
  $process.Dispose()
  [IO.File]::AppendAllText($log, "`nCOMMAND: $LeanExe $($Arguments -join ' ')`nSTDOUT:`n$stdout`nSTDERR:`n$stderr`nEXIT: $code`n", $encoding)
  [Console]::Out.Write($stdout)
  [Console]::Error.Write($stderr)
  if ($code -ne 0 -or $stdout -match 'sorryAx|error:') { throw 'Lean check failed; see verification.log' }
  return $stdout
}
$savedLeanPath = $env:LEAN_PATH
$env:LEAN_PATH = $OutputDirectory
try {
  $version = Invoke-Lean @('--version')
  if ($version -notmatch 'version 4\.34\.1,' -or $version -notmatch '5045d0056413266e57c625dcd7c365b10e377c52') { throw 'Expected recorded Lean 4.34.1 commit' }
  foreach ($step in $steps) {
    $result = Invoke-Lean $step.arguments
    if ($step.tests -and (($result -split '\r?\n' | Where-Object { $_ -match '^PASS:' }).Count -ne 7 -or $result -notmatch '7/7 tests passed')) { throw 'Expected seven passing tests' }
    foreach ($expected in $step.contains) { if (!$result.Contains($expected)) { throw "Missing result: $expected" } }
  }
  [IO.File]::AppendAllText($log, "`nREPRODUCTION: PASS`n", $encoding)
  Write-Host "REPRODUCTION: PASS ($OutputDirectory)"
} finally { $env:LEAN_PATH = $savedLeanPath }
