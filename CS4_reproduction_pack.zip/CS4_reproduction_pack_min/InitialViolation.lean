import C0
import L0

theorem c0_returns_last : C0 [1,2,2,3] 2 = some 2 := by
  decide

theorem c0_counterexample :
    ¬ FirstIndexSpec [1,2,2,3] 2 (C0 [1,2,2,3] 2) := by
  rw [c0_returns_last]
  intro h
  have bad := h.2.2 1 (by decide)
  exact bad (by decide)

theorem c0_not_universally_correct :
    ¬ (∀ a x, FirstIndexSpec a x (C0 a x)) := by
  intro h
  exact c0_counterexample (h [1,2,2,3] 2)

#print axioms c0_returns_last
#print axioms c0_counterexample
#print axioms c0_not_universally_correct
