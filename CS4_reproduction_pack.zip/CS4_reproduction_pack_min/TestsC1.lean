import C1
import T0
def main : IO Unit := T0 C1
