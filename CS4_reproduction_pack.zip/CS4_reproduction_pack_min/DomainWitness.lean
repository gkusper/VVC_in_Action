import AtMostOneOccurrence

theorem duplicate_target_excluded :
    ¬ AtMostOneOccurrence [1,2,2,3] 2 := by
  intro h
  have impossible : (1 : Nat) = 2 :=
    h ⟨1, by decide⟩ ⟨2, by decide⟩ (by decide) (by decide)
  exact (by decide : (1 : Nat) ≠ 2) impossible

-- Separate audit of the exact inherited test inputs; no change to T0.
theorem all_seven_T0_inputs_admitted :
    AtMostOneOccurrence [] 5 ∧
    AtMostOneOccurrence [5] 5 ∧
    AtMostOneOccurrence [1,3,5,7] 5 ∧
    AtMostOneOccurrence [1,3,5,7] 4 ∧
    AtMostOneOccurrence [1,3,5,7] 1 ∧
    AtMostOneOccurrence [1,3,5,7] 7 ∧
    AtMostOneOccurrence [-3,-1,0,2] (-1) := by
  unfold AtMostOneOccurrence
  decide

#print axioms duplicate_target_excluded
#print axioms all_seven_T0_inputs_admitted
