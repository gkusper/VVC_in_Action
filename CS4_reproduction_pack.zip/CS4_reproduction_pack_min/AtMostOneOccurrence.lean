import Std

-- Controlled new precondition: any two valid positions containing x coincide.
-- Other values may repeat freely. This restricts inputs, not the result property.
def AtMostOneOccurrence (a : List Int) (x : Int) : Prop :=
  ∀ i j : Fin a.length,
    a[i.val]? = some x → a[j.val]? = some x → i.val = j.val
