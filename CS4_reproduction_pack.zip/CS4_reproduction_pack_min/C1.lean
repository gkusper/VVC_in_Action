import Std

-- Requirement-preserving code repair: prefer the matching head.
def C1 : List Int → Int → Option Nat
  | [], _ => none
  | h :: t, x =>
    if h == x then some 0
    else (C1 t x).map (fun i => i + 1)
