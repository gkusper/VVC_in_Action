import AtMostOneOccurrence
import L0
import WeakCorrectness

theorem any_to_first_under_unique (a : List Int) (x : Int) (r : Option Nat)
    (hu : AtMostOneOccurrence a x) (hw : AnyIndexSpec a x r) :
    FirstIndexSpec a x r := by
  cases r with
  | none => exact hw
  | some i =>
    obtain ⟨hi, hv⟩ := hw
    refine ⟨hi, hv, ?_⟩
    intro j hji hj
    exact (Nat.ne_of_lt hji)
      (hu ⟨j, Nat.lt_trans hji hi⟩ ⟨i, hi⟩ hj hv)

theorem c0_restricted_universally_correct :
    ∀ a x, AtMostOneOccurrence a x → FirstIndexSpec a x (C0 a x) := by
  intro a x hu
  exact any_to_first_under_unique a x (C0 a x) hu
    (c0_weak_universally_correct a x)

#print axioms any_to_first_under_unique
#print axioms c0_restricted_universally_correct
