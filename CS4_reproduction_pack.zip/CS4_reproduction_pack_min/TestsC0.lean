import C0
import T0
def main : IO Unit := T0 C0
