import C0
import AnyIndexSpec

theorem c0_weak_correct (a : List Int) (x : Int) :
    AnyIndexSpec a x (C0 a x) := by
  induction a with
  | nil => simp [C0, AnyIndexSpec]
  | cons h t ih =>
    cases hr : C0 t x with
    | none =>
      rw [hr] at ih
      simp only [C0, hr]
      by_cases hx : h = x
      · subst h
        simp [AnyIndexSpec]
      · simp only [beq_iff_eq, hx, ↓reduceIte]
        intro j hj
        cases j with
        | zero => simpa using hx
        | succ k => simpa using ih k (by simpa using hj)
    | some i =>
      rw [hr] at ih
      simp only [C0, hr]
      exact ⟨by simpa using ih.1, by simpa using ih.2⟩

theorem c0_weak_universally_correct :
    ∀ a x, AnyIndexSpec a x (C0 a x) := c0_weak_correct

#print axioms c0_weak_universally_correct
