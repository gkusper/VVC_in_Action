import Std

-- Fixed researcher-specified seven cases. Parameterization allows unchanged reuse.
def T0 (search : List Int → Int → Option Nat) : IO Unit := do
  let cases : List (List Int × Int × Option Nat) := [
    ([], 5, none),
    ([5], 5, some 0),
    ([1,3,5,7], 5, some 2),
    ([1,3,5,7], 4, none),
    ([1,3,5,7], 1, some 0),
    ([1,3,5,7], 7, some 3),
    ([-3,-1,0,2], -1, some 1)]
  for (a, x, expected) in cases do
    let actual := search a x
    if actual != expected then
      throw (IO.userError s!"FAIL: {a}, {x}: got {actual}, expected {expected}")
    IO.println s!"PASS: {a}, {x} -> {actual}"
  IO.println "7/7 tests passed"
