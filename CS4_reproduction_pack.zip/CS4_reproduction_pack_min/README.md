# CS4 minimal reproduction package

Requires Lean 4.34.1 (commit 5045d0056413266e57c625dcd7c365b10e377c52), its bundled Std library, and PowerShell 7. No Mathlib or package download is required.

```powershell
pwsh -NoProfile -File ./reproduce.ps1 -LeanExe /path/to/lean
```

If Lean is on PATH, omit `-LeanExe`. The script checks source hashes and version, compiles dependencies, executes the tests and checks each theorem once. It writes generated files and `verification.log` under a new `replay/` directory; `-OutputDirectory` can select another location. A nonzero process exit indicates an unexpected result. Negative theorems are expected successful Lean checks.

Fixed requirement D0: Given a finite list of integers `a` and an integer `x`, return the zero-based index of the first occurrence of `x` in `a`. If `x` does not occur in the list, return no index. The result must never refer to an invalid list position.

A: C1 + L0 + Correctness. B: C0 + AnyIndexSpec + WeakCorrectness. C: C0 + L0 + AtMostOneOccurrence + RestrictedCorrectness. InitialViolation and the contrast/domain witnesses check the original defect and the scopes of the alternative guarantees. TestsC0 applies to the initial state and branches B/C; TestsC1 applies to A.

All Lean sources are byte-for-byte copies of the supplied full package, flattened without changing module names or contents. `reference.log` concatenates one archived execution per check, with original command metadata and unedited stdout/stderr payloads. Repeated proof runs, empty standalone files, intermediate proof attempts, duplicated frozen sources, long reports and prior-package copies are omitted. The paper explains the study design and interpretation.

Source archive: `CS4_reproduction_pack.zip`; SHA-256 `739e15639241fa8402a2985d4d3056ba2712dbd007de875444618576e7d7b4ce`.
