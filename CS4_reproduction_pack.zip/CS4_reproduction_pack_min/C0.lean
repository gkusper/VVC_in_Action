import Std

-- Researcher-specified controlled defect, implemented in this Codex session.
def C0 : List Int → Int → Option Nat
  | [], _ => none
  | h :: t, x =>
    match C0 t x with
    | some i => some (i + 1)
    | none => if h == x then some 0 else none
