import Std

-- Researcher-specified controlled under-specification for CS3.
-- Only the first-occurrence conjunct of FirstIndexSpec is omitted.
def AnyIndexSpec (a : List Int) (x : Int) (r : Option Nat) : Prop :=
  match r with
  | some i => i < a.length ∧ a[i]? = some x
  | none => ∀ j, j < a.length → a[j]? ≠ some x
