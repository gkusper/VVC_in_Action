import C0
import L0
import AnyIndexSpec
import WeakCorrectness

theorem cs3_c0_result : C0 [1,2,2,3] 2 = some 2 := by
  decide

theorem cs3_duplicate_weak :
    AnyIndexSpec [1,2,2,3] 2 (C0 [1,2,2,3] 2) :=
  c0_weak_universally_correct [1,2,2,3] 2

theorem cs3_duplicate_not_full :
    ¬ FirstIndexSpec [1,2,2,3] 2 (C0 [1,2,2,3] 2) := by
  rw [cs3_c0_result]
  intro h
  exact h.2.2 1 (by decide) (by decide)

#print axioms cs3_c0_result
#print axioms cs3_duplicate_weak
#print axioms cs3_duplicate_not_full
