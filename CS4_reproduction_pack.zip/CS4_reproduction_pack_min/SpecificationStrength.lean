import ConcreteContrast

theorem full_implies_weak :
    ∀ a x r, FirstIndexSpec a x r → AnyIndexSpec a x r := by
  intro a x r h
  cases r with
  | none => exact h
  | some i => exact ⟨h.1, h.2.1⟩

theorem weak_strictness_witness :
    ∃ a x r, AnyIndexSpec a x r ∧ ¬ FirstIndexSpec a x r := by
  refine ⟨[1,2,2,3], 2, some 2, ?_, ?_⟩
  · simpa only [cs3_c0_result] using cs3_duplicate_weak
  · simpa only [cs3_c0_result] using cs3_duplicate_not_full

theorem weak_does_not_imply_full :
    ¬ (∀ a x r, AnyIndexSpec a x r → FirstIndexSpec a x r) := by
  intro h
  obtain ⟨a,x,r,hw,hn⟩ := weak_strictness_witness
  exact hn (h a x r hw)

#print axioms full_implies_weak
#print axioms weak_strictness_witness
#print axioms weak_does_not_imply_full
