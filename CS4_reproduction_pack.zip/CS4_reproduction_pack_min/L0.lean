import Std

-- Fixed semantic encoding of D; no restriction to unique or sorted inputs.
def FirstIndexSpec (a : List Int) (x : Int) (r : Option Nat) : Prop :=
  match r with
  | some i => i < a.length ∧ a[i]? = some x ∧
      ∀ j, j < i → a[j]? ≠ some x
  | none => ∀ j, j < a.length → a[j]? ≠ some x
