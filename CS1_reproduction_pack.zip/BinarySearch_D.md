# Binary Search — Documentation Artifact (D)

**Role:** This document is the **declared source of truth** for the case study.
All other artifacts (C, T, L) are derived from and must be consistent with this document.

## Requirement

Given a sorted sequence of integers `a` and a value `x`, return an index `r` such that `a[r] == x`.
If `x` is not present, return `-1`.
The algorithm must not access the sequence out of bounds and should terminate.

## Assumptions

1. The input sequence `a` is sorted in non-decreasing order (i.e., for all valid indices `i < j`, `a[i] <= a[j]`).
2. The sequence may be empty.
3. The sequence uses zero-based indexing.
4. If `x` appears multiple times, returning any valid index is acceptable.
5. The value `-1` is used as a sentinel indicating "not found" and is never a valid index.

## Edge Cases

| Case | Input | Expected output |
|------|-------|-----------------|
| Empty sequence | `a = [], x = 5` | `r == -1` |
| Single element, found | `a = [5], x = 5` | `r == 0` |
| Single element, not found | `a = [5], x = 3` | `r == -1` |
| Target at lower bound | `a = [1,3,5,7,9], x = 1` | `r == 0` |
| Target at upper bound | `a = [1,3,5,7,9], x = 9` | `r == 4` |
| Target in middle | `a = [1,3,5,7,9], x = 5` | `r == 2` |
| Target absent (between values) | `a = [1,3,5,7,9], x = 4` | `r == -1` |

## Preconditions (to become Dafny `requires`)

- `Sorted(a)`: the input sequence is sorted in non-decreasing order.

## Postconditions (to become Dafny `ensures`)

- **Success case:** `r != -1 ==> 0 <= r < |a| && a[r] == x`
  - If a valid index is returned, it is in bounds and points to the target value.
- **Absent-key case:** `r == -1 ==> forall k :: 0 <= k < |a| ==> a[k] != x`
  - If `-1` is returned, the target value does not exist anywhere in the sequence.

## Loop Invariants (to become Dafny `invariant`)

- **Bounds:** `0 <= lo <= hi <= |a|`
- **Exclusion (left):** all elements before `lo` are not equal to `x` (or more precisely, the target cannot be in `a[..lo]`).
- **Exclusion (right):** all elements from `hi` onward are not equal to `x` (or more precisely, the target cannot be in `a[hi..]`).

## Termination (to become Dafny `decreases`)

- The measure `hi - lo` strictly decreases on each loop iteration and is bounded below by `0`.

## Definition of Done

1. All executable test cases from the edge-case table pass (`dafny run`).
2. All Dafny proof obligations are discharged without errors (`dafny verify`).
3. The logical specification (L) is consistent with this document — no postcondition was weakened or removed to pass verification.
