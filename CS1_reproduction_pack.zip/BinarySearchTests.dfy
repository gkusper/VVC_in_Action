// Artifact T: Executable test cases for BinarySearch
// These tests are derived from the edge-case table in BinarySearch_D.md,
// NOT from the implementation. They serve as Layer 1 verification.
//
// Source of truth: BinarySearch_D.md (edge-case table)

include "Sorted.dfy"
include "BinarySearch.dfy"

import opened SortedModule

method Main() {
  // Test 1: Empty sequence → returns -1
  var r1 := BinarySearch([], 5);
  expect r1 == -1, "Test 1 FAILED: empty sequence should return -1";
  print "Test 1 PASSED: empty sequence → -1\n";

  // Test 2: Single element, found → returns 0
  var r2 := BinarySearch([5], 5);
  expect r2 == 0, "Test 2 FAILED: single element found should return 0";
  print "Test 2 PASSED: single element found → 0\n";

  // Test 3: Single element, not found → returns -1
  var r3 := BinarySearch([5], 3);
  expect r3 == -1, "Test 3 FAILED: single element not found should return -1";
  print "Test 3 PASSED: single element not found → -1\n";

  // Test 4: Target at lower bound
  var r4 := BinarySearch([1, 3, 5, 7, 9], 1);
  expect r4 == 0, "Test 4 FAILED: lower bound target should return 0";
  print "Test 4 PASSED: lower bound target → 0\n";

  // Test 5: Target at upper bound
  var r5 := BinarySearch([1, 3, 5, 7, 9], 9);
  expect r5 == 4, "Test 5 FAILED: upper bound target should return 4";
  print "Test 5 PASSED: upper bound target → 4\n";

  // Test 6: Target in middle
  var r6 := BinarySearch([1, 3, 5, 7, 9], 5);
  expect r6 == 2, "Test 6 FAILED: middle target should return 2";
  print "Test 6 PASSED: middle target → 2\n";

  // Test 7: Target absent (between existing values)
  var r7 := BinarySearch([1, 3, 5, 7, 9], 4);
  expect r7 == -1, "Test 7 FAILED: absent target should return -1";
  print "Test 7 PASSED: absent target → -1\n";

  print "\nAll 7 tests passed.\n";
}
