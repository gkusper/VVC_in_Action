// Artifact L (part 1): Sorted predicate
// This module defines the logical specification for sortedness.
// It is the foundational predicate used in preconditions and invariants.
//
// Source of truth: BinarySearch_D.md
// "The input sequence is sorted in non-decreasing order
//  (i.e., for all valid indices i < j, a[i] <= a[j])."

module SortedModule {
  // Sorted(a) holds iff the sequence a is in non-decreasing order.
  // This is the mathematical definition: for all pairs of indices
  // where i < j, the value at position i is at most the value at position j.
  predicate Sorted(a: seq<int>) {
    forall i, j :: 0 <= i < j < |a| ==> a[i] <= a[j]
  }
}
