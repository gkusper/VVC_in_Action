// Artifacts C + L (part 2): Binary Search implementation with contracts
// This file contains the implementation (C) annotated with
// logical specifications (L): preconditions, postconditions,
// loop invariants, and termination measure.
//
// Source of truth: BinarySearch_D.md
// The specification below is derived from the documented requirement,
// NOT from the implementation. The implementation must satisfy the spec.

include "Sorted.dfy"

import opened SortedModule

// BinarySearch: searches for value x in sorted sequence a.
// Returns an index r where a[r] == x, or -1 if x is not present.
method BinarySearch(a: seq<int>, x: int) returns (r: int)
  // --- Artifact L: Precondition ---
  // From D: "Given a sorted sequence of integers a"
  requires Sorted(a)

  // --- Artifact L: Postconditions ---
  // From D: "return an index r such that a[r] == x"
  ensures r != -1 ==> 0 <= r < |a| && a[r] == x
  // From D: "If x is not present, return -1"
  ensures r == -1 ==> forall k :: 0 <= k < |a| ==> a[k] != x
{
  // --- Artifact C: Implementation ---
  // Handle empty sequence: immediate not-found
  if |a| == 0 {
    return -1;
  }

  var lo: int := 0;
  var hi: int := |a|;

  while lo < hi
    // --- Artifact L: Loop invariants ---
    // Bounds invariant: lo and hi stay within valid range
    invariant 0 <= lo <= hi <= |a|
    // Exclusion invariant (left): x is not in a[..lo]
    invariant forall k :: 0 <= k < lo ==> a[k] != x
    // Exclusion invariant (right): x is not in a[hi..]
    invariant forall k :: hi <= k < |a| ==> a[k] != x
    // --- Artifact L: Termination measure ---
    // hi - lo strictly decreases each iteration, bounded below by 0
    decreases hi - lo
  {
    var mid := lo + (hi - lo) / 2;

    if a[mid] < x {
      // Target is in upper half; discard a[..mid+1]
      lo := mid + 1;
    } else if a[mid] > x {
      // Target is in lower half; discard a[mid..]
      hi := mid;
    } else {
      // Found: a[mid] == x
      return mid;
    }
  }

  // Loop exited with lo == hi, meaning x was not found
  return -1;
}
