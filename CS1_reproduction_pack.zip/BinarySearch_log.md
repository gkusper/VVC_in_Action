# Binary Search Case Study — Iteration Log

## Metadata

| Field | Value |
|-------|-------|
| **Dafny version** | 4.11.0+fcb2042d6d043a2634f0854338c08feeaaaf4ae2 |
| **LLM** | Claude Opus 4.6 (Thinking) via Antigravity IDE |
| **Date** | 2026-07-06 |
| **Paper** | "Verified Vibe Coding in Action" (Kusper & Herbák, SYNASC 2026) |
| **Protocol** | Plan–Guide–Verify |
| **Source of truth** | Documentation artifact D (`BinarySearch_D.md`) |

---

## Iteration 1: Plan Phase

### Reasoning (LLM)

The Plan–Guide–Verify protocol requires that the source of truth is the documentation artifact D, written in natural language. The requirement text is defined in `BinarySearch_D.md`. Before writing any code, the LLM must:

1. Restate the requirement
2. List preconditions, postconditions, edge cases
3. Identify which parts become Dafny `requires`, `ensures`, `invariant`, `decreases`
4. State the Definition of Done

The planning prompt used was:
> *"Do not write code yet. Restate the binary-search requirement in your own words. List the preconditions, postconditions, edge cases, and the Definition of Done. Identify which parts should become Dafny requires, ensures, loop invariants, or asserts."*

### Action

Created `BinarySearch_D.md` containing:
- The natural-language requirement
- 5 assumptions (sorted, may be empty, zero-indexed, any valid index for duplicates, -1 as sentinel)
- 7 edge cases in tabular form
- Precondition mapping: `Sorted(a)` → Dafny `requires`
- Postcondition mapping: success case and absent-key case → Dafny `ensures`
- Loop invariant mapping: bounds + exclusion → Dafny `invariant`
- Termination mapping: `hi - lo` → Dafny `decreases`
- Definition of Done: tests pass AND verifier passes AND no spec weakening

### Result

Documentation artifact established. No code generated yet. In the Plan phase, the LLM is not asked to write code immediately.

---

## Iteration 2: Guide Phase — Artifact L (part 1): Sorted Predicate

### Reasoning (LLM)

The minimal target for L includes "a predicate `Sorted(a)` stating that earlier positions contain values no larger than later positions." From D, the assumption is: "for all valid indices `i < j`, `a[i] <= a[j]`."

I placed this in a separate module (`SortedModule`) in `Sorted.dfy` so it can be imported independently by both the implementation and the test files. This is the multi-file approach.

The predicate is a direct mathematical transcription:
```dafny
predicate Sorted(a: seq<int>) {
  forall i, j :: 0 <= i < j < |a| ==> a[i] <= a[j]
}
```

### Design Decisions

- Used `seq<int>` (immutable sequence) rather than `array<int>` because Dafny sequences are value types and simplify the specification (no heap reasoning).
- The `forall i, j` quantifier ranges over all pairs `i < j`, which is the standard mathematical definition of non-decreasing order.
- An alternative would be `forall i :: 0 <= i < |a| - 1 ==> a[i] <= a[i+1]` (adjacent pairs only), which is equivalent for transitivity but Dafny's verifier handles both forms well. The all-pairs version is more directly aligned with the requirement's language.

### Action

Created `Sorted.dfy` with module `SortedModule` containing the `Sorted` predicate.

### Result

File created. No verification run yet (waiting for all artifacts to be generated per the Guide phase protocol).

---

## Iteration 3: Guide Phase — Artifacts C + L (part 2): BinarySearch Method

### Reasoning (LLM)

The minimal target for L specifies four essential elements:
1. Predicate `Sorted(a)` — already done in Sorted.dfy
2. Precondition `requires Sorted(a)`
3. Success postcondition: `r != -1 ==> 0 <= r < |a| && a[r] == x`
4. Absent-key postcondition: `r == -1 ==> forall k :: 0 <= k < |a| ==> a[k] != x`

Plus loop invariants (bounds, exclusion for discarded interval) and termination measure.

The Guide phase requires that T and L should be generated before accepting C, to reduce circular validation. In this case, L (the contracts) and C (the implementation) are co-located in the same file because Dafny requires contracts to be attached to the method. However, the key principle is satisfied: the contracts were **derived from D** (the documentation), not from the implementation.

### Design Decisions

- **Exclusion invariants**: The key insight for binary search verification is that the loop maintains the property that `x` is NOT in the discarded portions of the array. I expressed this as two separate invariants:
  - `forall k :: 0 <= k < lo ==> a[k] != x` (left exclusion)
  - `forall k :: hi <= k < |a| ==> a[k] != x` (right exclusion)
  
  These work because `Sorted(a)` guarantees that when `a[mid] < x`, all elements at indices ≤ mid are also < x (hence ≠ x), and similarly for the other direction.

- **Empty sequence handling**: Added an explicit `if |a| == 0 { return -1; }` before the loop. This is not strictly necessary (the loop wouldn't execute with `lo = 0, hi = 0`), but it makes the code more readable.

- **Integer overflow avoidance**: Used `lo + (hi - lo) / 2` instead of `(lo + hi) / 2` for computing the midpoint. While Dafny uses mathematical integers (no overflow), this is good practice and matches the standard robust implementation.

- **Termination**: `decreases hi - lo` is the natural measure. Each branch either increases `lo` (setting `lo := mid + 1`, which increases lo by at least 1 since `mid >= lo`) or decreases `hi` (setting `hi := mid`, which decreases hi since `mid < hi` when `lo < hi`).

### Action

Created `BinarySearch.dfy` with:
- `include "Sorted.dfy"` and `import opened SortedModule`
- Method `BinarySearch` with full contracts and implementation
- Every contract line annotated with a comment tracing it back to D

### Result

File created. Contracts derived from D, implementation written to satisfy contracts.

---

## Iteration 4: Guide Phase — Artifact T: Tests

### Reasoning (LLM)

The artifact table in D specifies: "Executable example checks for empty sequence, found element, absent element, lower bound, and upper bound."

The tests must be derived from D's edge-case table, NOT from the implementation. This is the anti-circular-validation principle. I translated each row of the edge-case table from `BinarySearch_D.md` into a Dafny `expect` statement.

### Design Decisions

- Used Dafny's `expect` statement (runtime assertion) rather than `assert` (compile-time proof obligation). `expect` is appropriate here because tests check concrete values, not universal properties.
- Each test includes a descriptive failure message and a print on success for human-readable output.
- The tests use sequence literals like `[1, 3, 5, 7, 9]`. Dafny can verify that these are `Sorted` at compile time.

### Action

Created `BinarySearchTests.dfy` with 7 test cases matching the edge-case table in D.

### Result

File created. All Guide phase artifacts now exist.

---

## Iteration 5: Verify Phase — Layer 2 (Formal Verification)

### Reasoning (LLM)

Running formal verification first (before tests) because it is the stronger check. If verification fails, I need to repair before even running tests. The command verifies all three files together.

### Command

```
.\dafny\Dafny.exe verify Sorted.dfy BinarySearch.dfy BinarySearchTests.dfy
```

### Output

```
Dafny program verifier finished with 4 verified, 0 errors
```

### Detailed Verification Timings

| Proof obligation | Outcome | Time (s) | SMT Resources |
|-----------------|---------|----------|---------------|
| `SortedModule.Sorted` well-formedness | Correct | 0.014 | 8,876 |
| `BinarySearch` well-formedness | Correct | 0.034 | 11,850 |
| `BinarySearch` correctness | Correct | 0.033 | 67,203 |
| `Main` correctness | Correct | 0.055 | 58,475 |
| **Total (wall-clock)** | **4 verified** | **1.13** | **146,404** |

The `BinarySearch` correctness check discharged 24 assertions:
- 3× loop invariant holds on entry
- 3× loop invariant is maintained by the loop
- 2× postcondition holds
- 1× loop terminates
- 1× decreases expression bounded below by 0
- 3× index in range (array bounds)
- 1× divisor is always non-zero
- 3× definite-assignment (out-parameter initialized)
- 2× index in range (exclusion invariant quantifiers)

### Analysis

All 4 proof obligations were discharged:
1. `Sorted` predicate (well-formedness) — in `Sorted.dfy`
2. `BinarySearch` method (preconditions, postconditions, loop invariants, termination) — in `BinarySearch.dfy`  
3. `Main` method and its `expect` statements — in `BinarySearchTests.dfy`
4. Implicit checks (array bounds, integer arithmetic) — across all files

**No repair needed.** The contracts derived from D were sufficient for the verifier to discharge all obligations on the first attempt.

### Specification Weakening Check

**PASS** — No postconditions were removed or weakened. The logical specification L still exactly matches what was documented in D:
- ✅ `requires Sorted(a)` — present
- ✅ `ensures r != -1 ==> 0 <= r < |a| && a[r] == x` — present
- ✅ `ensures r == -1 ==> forall k :: 0 <= k < |a| ==> a[k] != x` — present
- ✅ Loop invariants (bounds + exclusion) — present
- ✅ `decreases hi - lo` — present

---

## Iteration 6: Verify Phase — Layer 1 (Executable Tests)

### Reasoning (LLM)

Running tests as the second layer. Even though formal verification passed, tests provide concrete evidence that the implementation behaves correctly on specific inputs. They also verify the runtime behavior (which is different from the proof-time behavior in subtle edge cases).

### Command

```
.\dafny\Dafny.exe run BinarySearchTests.dfy
```

### Wall-clock time: 5.06 seconds
(includes verification of test file, compilation to C#, and runtime execution)

### Output

```
Dafny program verifier finished with 1 verified, 0 errors
Test 1 PASSED: empty sequence → -1
Test 2 PASSED: single element found → 0
Test 3 PASSED: single element not found → -1
Test 4 PASSED: lower bound target → 0
Test 5 PASSED: upper bound target → 4
Test 6 PASSED: middle target → 2
Test 7 PASSED: absent target → -1

All 7 tests passed.
```

### Analysis

All 7 test cases from D's edge-case table pass. The `run` command also re-verified the test file (1 verified, 0 errors) before executing.

**No repair needed.**

---

## Summary

| Iteration | Phase | Action | Result | Repair needed? |
|-----------|-------|--------|--------|----------------|
| 1 | Plan | Created D artifact | Documentation established | — |
| 2 | Guide | Created `Sorted.dfy` (L part 1) | Predicate defined | — |
| 3 | Guide | Created `BinarySearch.dfy` (C + L part 2) | Method + contracts defined | — |
| 4 | Guide | Created `BinarySearchTests.dfy` (T) | 7 tests defined | — |
| 5 | Verify | `dafny verify` (Layer 2) | **4 verified, 0 errors** | No |
| 6 | Verify | `dafny run` (Layer 1) | **7/7 tests passed** | No |

### Definition of Done Status

| Criterion | Status |
|-----------|--------|
| All executable tests pass | ✅ 7/7 passed |
| All Dafny proof obligations discharged | ✅ 4 verified, 0 errors |
| L is consistent with D (no spec weakening) | ✅ All contracts match D |

### Artifacts Produced

| Artifact | File | Source of truth |
|----------|------|-----------------|
| D (documentation) | `BinarySearch_D.md` | D itself (declared) |
| L (logical spec, part 1) | `Sorted.dfy` | Derived from D |
| C + L (code + contracts) | `BinarySearch.dfy` | Derived from D |
| T (tests) | `BinarySearchTests.dfy` | Derived from D |

### Two-Layer Contrast Observation

The Plan–Guide–Verify protocol notes that a more useful demonstration would be a two-layer contrast: a generated solution that passes example tests but fails Dafny verification because a loop invariant is missing or too weak.

In this case study, both layers passed on the first attempt. This means the LLM-generated verification artifacts were sufficient without repair. While this does not demonstrate the two-layer contrast, it does demonstrate that **H3** (LLMs can lower the barrier to the fourth artifact) is plausible: the contracts, invariants, and termination measure were generated correctly from the documentation, and the external verifier confirmed them.

The absence of repair iterations is itself a data point. It suggests that for well-understood algorithms like binary search, modern LLMs can produce not just working code but also correct formal specifications — when guided by a structured Plan–Guide–Verify protocol with a clear source of truth.
