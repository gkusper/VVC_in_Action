# Minimal repack: evaluation functions preserved from the supplied full package.
from pathlib import Path
import argparse,zipfile,xml.etree.ElementTree as ET,hashlib,json,csv,collections
import subprocess,datetime,re,sys,concurrent.futures,shutil
PACKAGE=Path(__file__).resolve().parent
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}

def sha(b): return hashlib.sha256(b).hexdigest()

def norm(s):return s.replace('\u00a0',' ').replace('\r\n','\n').replace('\r','\n')

def write(p,s):
 p=ROOT/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(s.encode('utf-8'))

def csvout(p,rows):
 with (ROOT/p).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def extract():
 p=next((ROOT/'input').glob('*.xlsx'))
 with zipfile.ZipFile(p) as z:
  text=lambda e:''.join(t.text or '' for t in e.findall('.//s:t',NS))
  ss=[text(x) for x in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',NS)]
  cells={}
  for c in ET.fromstring(z.read('xl/worksheets/sheet1.xml')).findall('.//s:sheetData/s:row/s:c',NS):
   v=c.find('s:v',NS);s=ss[int(v.text)] if c.get('t')=='s' else text(c) if c.get('t')=='inlineStr' else (v.text or '' if v is not None else '')
   if s:cells[c.get('r')]=s
 headers={chr(c):cells.get(chr(c)+'1','') for c in range(66,91)}
 participants={r:cells['A'+str(r)] for r in range(2,1001) if 'A'+str(r) in cells}
 runs=[]
 for r,sign in participants.items():
  for col,label in headers.items():
   cell=col+str(r)
   if cell not in cells:continue
   raw=cells[cell];n=norm(raw);rid=f'R{len(runs)+1:03}'
   runs.append(dict(run_id=rid,workbook_cell='Munka1!'+cell,call_sign=sign,model_label=label,column=col,raw_content=raw,raw_hash=sha(raw.encode()),normalized_hash=sha(n.encode()),whitespace_normalization='NBSP' if '\u00a0' in raw else 'LINE_ENDINGS' if raw!=n else 'NONE'))
 labeled={c:l for c,l in headers.items() if l};counts=collections.Counter(x['column'] for x in runs)
 audit=dict(sheet='Munka1',participant_count=len(participants),distinct_call_signs=len(set(participants.values())),model_columns=len(labeled),active_configurations=len(counts),non_empty_runs=len(runs),not_attempted=len(participants)*len(labeled)-len(runs),blank_header_columns=[c for c,l in headers.items() if not l],unassigned_blank_slots=len(participants)*sum(not l for l in headers.values()),duplicate_labels=[l for l,n in collections.Counter(labeled.values()).items() if n>1],headers=headers,counts=dict(counts),workbook_sha256=sha(p.read_bytes()))
 return runs,audit

TEMPLATE='''method Reverse(a: array<int>)
  modifies a
  ensures forall k :: 0 <= k < a.Length ==>
            a[k] == old(a[a.Length - 1 - k])
{
  ghost var orig := a[..];
  var i := 0;
  var j := a.Length - 1;

  while i < j
    // TODO: invariant(s)
    decreases j - i
  {
    a[i], a[j] := a[j], a[i];
    i := i + 1;
    j := j - 1;
  }
}
'''

def source(response):return TEMPLATE.replace('    // TODO: invariant(s)',response)

def classify(code,out):
 diagnostics='\n'.join(l for l in out.splitlines() if 'Error:' in l or 'Related location:' in l or 'Warning:' in l)
 if re.search(r'parse errors? detected|resolution/type errors? detected',out):return dict(syntax='FAIL',inductive='NOT_REACHED',full_verification='NOT_REACHED',induction_failure='NOT_REACHED',diagnostics=diagnostics)
 if code==0 and re.search(r'\b0 errors\b',out):return dict(syntax='PASS',inductive='PASS',full_verification='PASS',induction_failure='NONE',diagnostics=diagnostics)
 if re.search(r'Dafny program verifier finished with.*[1-9]\d* errors?',out):
  init='could not be proved on entry' in out
  pres='could not be proved to be maintained' in out or 'invariant violation' in out
  ind='FAIL' if init or pres else 'UNRESOLVED'
  return dict(syntax='PASS',inductive=ind,full_verification='FAIL',induction_failure='BOTH / MULTIPLE' if init and pres else 'INITIATION_FAILURE' if init else 'PRESERVATION_FAILURE' if pres else 'UNRESOLVED',diagnostics=diagnostics)
 return dict(syntax='UNKNOWN',inductive='NOT_REACHED',full_verification='NOT_REACHED',induction_failure='TOOL_OR_ENVIRONMENT_ERROR',diagnostics=diagnostics)

def run(candidate,logbase,extra=None):
 candidate=ROOT/candidate;logbase=ROOT/logbase;logbase.parent.mkdir(parents=True,exist_ok=True)
 cmd=[str(DAFNY),'verify',str(candidate),'--solver-path',str(SOLVER),'--cores','1']+(extra or [])
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:
  p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60);code=p.returncode;out=p.stdout;err=p.stderr
 except subprocess.TimeoutExpired as e:code=-999;out=e.stdout or b'';err=e.stderr or b''
 logbase.with_suffix('.stdout.txt').write_bytes(out);logbase.with_suffix('.stderr.txt').write_bytes(err)
 result=classify(code,(out+b'\n'+err).decode('utf-8',errors='replace'))
 result.update(exit_code=code,command=cmd,started_utc=start,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate_sha256=sha(candidate.read_bytes()))
 logbase.with_suffix('.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 return result

def compliance(r):
 # Reviewed from this workbook: R032 contains only three wrapped invariant expressions.
 # A physical continuation line is not extraneous prose.
 return 'FAIL' if r['run_id'] in ['R053','R059'] else 'PASS'

def symmetry(s):
 s=re.sub(r'\s+','',s).replace('old(a.Length)','a.Length')
 return any(x in s for x in ['i+j==a.Length-1','j==a.Length-1-i','i==a.Length-1-j'])

def one(r,prefix=''):
 rid=r['run_id'];raw=r['raw_content'];n=norm(raw)
 base=prefix+'logs/'+rid+'/'
 write(prefix+'candidates/verbatim/'+rid+'.dfy',source(raw))
 rawresult=run(prefix+'candidates/verbatim/'+rid+'.dfy',base+'verbatim')
 write(prefix+'candidates/strict/'+rid+'.dfy',source(n))
 result=run(prefix+'candidates/strict/'+rid+'.dfy',base+'normalized') if n!=raw else rawresult
 if result['inductive']=='UNRESOLVED':
  detailed=run(prefix+'candidates/strict/'+rid+'.dfy',base+'obligation-audit',['--isolate-assertions','--error-limit','0','--log-format','text'])
  result=dict(result,inductive=detailed['inductive'],induction_failure=detailed['induction_failure'],diagnostics=result['diagnostics']+'\nOBLIGATION AUDIT:\n'+detailed['diagnostics'])
 instruction=compliance(r)
 # Manual inspection of all 60 response texts found no bypass or program/spec edits.
 bypass=bool(re.search(r'\bassume\b|\{:\s*(?:axiom|verify\s+false)|decreases\s*\*|\b(?:method|requires|ensures|modifies)\b',n))
 primary='INSTRUCTION_OR_FORMAT_FAILURE' if instruction=='FAIL' else 'PROHIBITED_MODIFICATION_OR_BYPASS' if bypass else 'SYNTAX_OR_TYPE_ERROR' if result['syntax']=='FAIL' else 'FULL_SUCCESS' if result['full_verification']=='PASS' else 'NON_INDUCTIVE_INVARIANT' if result['inductive']=='FAIL' else 'INDUCTIVE_BUT_INSUFFICIENT' if result['inductive']=='PASS' else 'TOOL_OR_ENVIRONMENT_ERROR'
 salvage='NOT_APPLICABLE';extracted='';salres=None
 if instruction=='FAIL':
  extracted=norm('\n'.join(l for l in raw.splitlines() if l.strip().startswith('invariant')))
  write(prefix+'responses/extracted/'+rid+'.txt',extracted)
  if extracted:
   write(prefix+'candidates/salvaged/'+rid+'.dfy',source(extracted));salres=run(prefix+'candidates/salvaged/'+rid+'.dfy',base+'salvaged')
   salvage='SALVAGED_FULL_SUCCESS' if salres['full_verification']=='PASS' else 'SALVAGED_SYNTAX_FAILURE' if salres['syntax']=='FAIL' else 'SALVAGED_NON_INDUCTIVE' if salres['inductive']=='FAIL' else 'SALVAGED_INSUFFICIENT' if salres['inductive']=='PASS' else 'TOOL_OR_ENVIRONMENT_ERROR'
  else:salvage='NOT_SALVAGEABLE'
 out={k:v for k,v in r.items() if k!='raw_content'}
 out.update(extracted_invariant_hash=sha(extracted.encode()) if extracted else '',instruction_compliance=instruction,**{k:result[k] for k in ['syntax','inductive','full_verification','induction_failure','exit_code','diagnostics']},strict_full_success=primary=='FULL_SUCCESS',primary_classification=primary,salvage_status=salvage,content_full_success=primary=='FULL_SUCCESS' or salvage=='SALVAGED_FULL_SUCCESS',bypass_detected=bypass,symmetry_present=symmetry(n),symmetry_repair_result='NOT_APPLICABLE',evaluation_anomaly='NONE',notes='Wrapped expressions are invariant-only content.' if rid=='R032' else 'INTERACTION-LEVEL FAILURE — SOURCE NOT DISAMBIGUATED' if instruction=='FAIL' or result['syntax']=='FAIL' else '')
 out['primary_result']=result;out['salvage_result']=salres
 write(prefix+'logs/'+rid+'/result.json',json.dumps(out,ensure_ascii=False,indent=2))
 print(rid,primary,salvage,flush=True)
 return out

def build(rows,repairs,prefix=''):
 repairmap={x['run_id']:x for x in repairs}
 output=[]
 for original in rows:
  r={k:v for k,v in original.items() if k not in ['primary_result','salvage_result']}
  rid=r['run_id'];d=repairmap.get(rid)
  r['symmetry_repair_result']=d['result'] if d else 'NOT_APPLICABLE'
  r['symmetry_repair_stage']=d['stage'] if d else ''
  reason='NONE'
  if r['primary_classification']=='INSTRUCTION_OR_FORMAT_FAILURE':reason='quoted response; mechanically retained trailing quote causes salvage syntax failure' if rid=='R053' else 'Markdown wrapper; extracted invariants omit index symmetry'
  elif r['syntax']=='FAIL':reason={'R019':'unresolved identifiers (ak/origa/origk)','R020':'sequence .Length member is invalid','R051':'sequence .Length member is invalid','R058':'nested old expression is disallowed','R060':'malformed implication/operator syntax'}[rid]
  elif r['full_verification']=='FAIL':
   reason='missing index-symmetry relation (single-clause repair verifies)' if d and d['result']=='REPAIRED_BY_SYMMETRY' else 'inadequate bounds and missing untouched-middle/index symmetry' if rid=='R044' else 'missing untouched-middle and index-symmetry relations' if rid=='R057' else 'other verifier failure; see diagnostics'
  r['main_failure_reason']=reason
  if r['primary_classification']!='FULL_SUCCESS' and 'SOURCE NOT DISAMBIGUATED' not in r['notes']:r['notes']=(r['notes']+'; ' if r['notes'] else '')+'INTERACTION-LEVEL FAILURE — SOURCE NOT DISAMBIGUATED'
  if rid=='R044':r['notes']+='; Default error limit hid preservation failures; unchanged-source assertion isolation exposed them.'
  output.append(r)
 csvout(prefix+'RESULTS_RUN_LEVEL.csv',output)
 audit=json.loads((ROOT/'audit.json').read_text(encoding='utf-8'));models=[]
 for label in dict.fromkeys(audit['headers'].values()):
  if not label:continue
  rs=[r for r in output if r['model_label']==label];n=len(rs);strict=sum(r['strict_full_success'] for r in rs);content=sum(r['content_full_success'] for r in rs)
  mixed=0<strict<n
  pattern='NOT ATTEMPTED' if not n else 'MIXED / RUN-TO-RUN VARIATION' if mixed else 'OBSERVED CONSISTENT SUCCESS' if n>=3 and strict==n else 'OBSERVED CONSISTENT NON-SUCCESS' if n>=3 else 'EXPLORATORY SUCCESS — FEW OBSERVATIONS' if strict==n else 'EXPLORATORY NON-SUCCESS — FEW OBSERVATIONS'
  models.append(dict(model_label=label,attempts=n,instruction_pass=sum(r['instruction_compliance']=='PASS' for r in rs),syntax_pass=sum(r['syntax']=='PASS' for r in rs),inductive_pass=sum(r['inductive']=='PASS' for r in rs),strict_full_success=strict,strict_success_rate=strict/n if n else '',content_full_success=content,content_success_rate=content/n if n else '',mixed_outcome=mixed,observed_pattern=pattern,main_failure_modes=json.dumps(dict(collections.Counter(r['main_failure_reason'] for r in rs if r['main_failure_reason']!='NONE')),ensure_ascii=False),notes='Exact workbook label; descriptive observations only.'))
 csvout(prefix+'RESULTS_MODEL_LEVEL.csv',models)
 return output,models

def main():
 global ROOT,DAFNY,SOLVER
 parser=argparse.ArgumentParser(description='Replay the packaged workbook and compare with frozen reference outcomes.')
 parser.add_argument('--dafny',required=True);parser.add_argument('--solver',required=True);parser.add_argument('--output-directory')
 args=parser.parse_args();DAFNY=Path(args.dafny).resolve();SOLVER=Path(args.solver).resolve()
 ROOT=Path(args.output_directory).resolve() if args.output_directory else PACKAGE/'replay'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
 ROOT.mkdir(parents=True,exist_ok=False)
 def readcsv(path):
  with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
 references=readcsv(PACKAGE/'RESULTS_RUN_LEVEL.csv')
 expecteddiag=readcsv(PACKAGE/'DIAGNOSTICS.csv')
 workbook=PACKAGE/'VVC_in_Action_Dafny_invariant.v.1.1.xlsx'
 assert sha(workbook.read_bytes())=='54f9f3e06063bb90eccccdad9ce0fe4c2a3ce303c3528bf8761d1c933fcc334e','Workbook hash differs'
 (ROOT/'input').mkdir();shutil.copyfile(workbook,ROOT/'input'/workbook.name)
 for name,cmd,expected in [('dafny',[str(DAFNY),'--version'],'4.11.0+fcb2042d6d043a2634f0854338c08feeaaaf4ae2'),('z3',[str(SOLVER),'--version'],'Z3 version 4.12.1 - 64 bit')]:
  result=subprocess.run(cmd,capture_output=True);(ROOT/(name+'.stdout.txt')).write_bytes(result.stdout);(ROOT/(name+'.stderr.txt')).write_bytes(result.stderr)
  assert result.returncode==0 and result.stdout.decode().strip()==expected,(name,'version mismatch')
 runs,audit=extract();write('audit.json',json.dumps(audit,ensure_ascii=False,indent=2))
 assert len(runs)==len(references)==60
 for r,ref in zip(runs,references):
  for key in ['run_id','workbook_cell','call_sign','model_label','raw_hash','normalized_hash']:assert r[key]==ref[key],(r['run_id'],key,'inventory drift')
  write('responses/raw/'+r['run_id']+'.txt',r['raw_content']);write('responses/normalized/'+r['run_id']+'.txt',norm(r['raw_content']))
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(one,runs))
 fields=['instruction_compliance','syntax','inductive','full_verification','strict_full_success','primary_classification','salvage_status','content_full_success','exit_code','induction_failure','raw_hash','normalized_hash','extracted_invariant_hash']
 drift=[];groups=collections.defaultdict(list)
 for result,ref in zip(results,references):
  for key in fields:
   if str(result[key])!=ref[key]:drift.append(dict(run_id=result['run_id'],field=key,expected=ref[key],actual=result[key]))
  result['duplicate_cluster']=ref['duplicate_cluster'];groups[result['normalized_hash']].append(result)
 for h,group in groups.items():
  if len({(r['syntax'],r['inductive'],r['full_verification'],r['exit_code']) for r in group})>1:
   repeats=[run('candidates/strict/'+group[0]['run_id']+'.dfy',f'consistency/{group[0]["run_id"]}-{i}') for i in range(1,4)]
   drift.append(dict(hash=h,reason='Identical normalized responses inconsistent; three retained reruns require review',repeats=repeats))
 # Freeze before all post-hoc checks, even when a drift is encountered.
 write('primary_results.json',json.dumps(results,ensure_ascii=False,indent=2))
 inventory={r['run_id']:r for r in runs};jobs=[]
 for r in results:
  rid=r['run_id']
  for stage,result,txt in [('strict',r['primary_result'],norm(inventory[rid]['raw_content'])),('salvaged',r['salvage_result'],(ROOT/'responses/extracted'/f'{rid}.txt').read_text(encoding='utf-8') if r['salvage_result'] else '')]:
   if not result or result['syntax']!='PASS' or result['full_verification']!='FAIL' or symmetry(txt):continue
   candidate=f'diagnostic_repairs/{rid}-{stage}.dfy';write(candidate,source(txt+'\ninvariant i + j == a.Length - 1'))
   jobs.append(dict(check='symmetry',id=rid,stage=stage,response_line='',candidate=candidate))
 unique={}
 for r in results:
  if r['strict_full_success']:unique.setdefault(r['normalized_hash'],r)
 for index,r in enumerate(unique.values(),1):
  sid=f'S{index:03}';lines=norm(inventory[r['run_id']]['raw_content']).split('\n')
  for lineno,line in enumerate(lines):
   if not line.strip().startswith('invariant'):continue
   candidate=f'ablation/{sid}-L{lineno+1:02}.dfy';write(candidate,source('\n'.join(lines[:lineno]+lines[lineno+1:])))
   jobs.append(dict(check='ablation',id=sid,stage=r['run_id'],response_line=lineno+1,candidate=candidate))
 def diagnostic(job):
  result=run(job['candidate'],'diagnostic_logs/'+Path(job['candidate']).stem)
  return dict(job,**result)
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:diagnostics=list(pool.map(diagnostic,jobs))
 key=lambda r:(r['check'],r['id'],r['stage'],str(r['response_line']))
 expected={key(r):r for r in expecteddiag};actual={key(r):r for r in diagnostics}
 if set(expected)!=set(actual):drift.append(dict(reason='Diagnostic set differs'))
 for k in expected.keys() & actual.keys():
  for field in ['candidate_sha256','syntax','inductive','full_verification','exit_code']:
   if str(actual[k][field])!=expected[k][field]:drift.append(dict(check=k,field=field,expected=expected[k][field],actual=actual[k][field]))
 repairs=[dict(r,run_id=r['id'],result='REPAIRED_BY_SYMMETRY' if r['full_verification']=='PASS' else 'NOT_REPAIRED_BY_SYMMETRY') for r in diagnostics if r['check']=='symmetry']
 build(results,repairs)
 write('diagnostic_results.json',json.dumps(diagnostics,ensure_ascii=False,indent=2))
 summary=dict(status='PASS' if not drift else 'FAIL',primary_runs=len(results),strict_success=sum(r['strict_full_success'] for r in results),symmetry_checks=len(repairs),ablation_checks=len(diagnostics)-len(repairs),drift=drift)
 write('SUMMARY.json',json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,indent=2));print('Replay outputs:',ROOT)
 if drift:raise SystemExit(1)
if __name__=='__main__':main()
