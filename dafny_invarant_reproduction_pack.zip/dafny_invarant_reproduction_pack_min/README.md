# Dafny invariant study: minimal reproduction

Requires Python 3.10+ (standard library only), Dafny 4.11.0 build fcb2042d6d043a2634f0854338c08feeaaaf4ae2 and Z3 4.12.1. The original workbook is included byte-for-byte.

```text
python reproduce.py --dafny /path/to/dafny --solver /path/to/z3-4.12.1
```

The script regenerates the fixed method and all candidates from Excel, checks raw responses before permitted NBSP/line-ending normalization, performs primary and mechanical salvage evaluation, checks identical-response consistency, and regenerates run/model tables. It then regenerates all 16 symmetry and 118 leave-one-physical-line-out diagnostics and compares outcomes to DIAGNOSTICS.csv. No candidate repairs affect primary scores. Generated sources and raw outputs go into a new `replay/<UTC timestamp>/` directory; no reference file is overwritten. Nonzero exit indicates unexpected drift.

Files: workbook (observations); reproduce.py (fixed template and evaluator); RESULTS_RUN_LEVEL.csv (frozen reference results/provenance); RESULTS_MODEL_LEVEL.csv (reference aggregation); DIAGNOSTICS.csv (reference post-hoc outcomes and source hashes); reference.log (one original raw execution per primary, salvage and diagnostic check, framed with original metadata). The study design and interpretation are in the paper, not repeated here.

Expected primary totals: 60 responses, 58 instruction PASS, 53 syntax PASS, 38 strict/content successes; 6 mixed configurations. Symmetry completes 13 primary and 1 salvage candidate. The primary scores remain 38/60. R032's expression wrapping is accepted as invariant-only content; R053's quotes and R059's fences fail instruction compliance. Extraction retains the trailing quote in R053. R044 requires unchanged-source assertion isolation to expose preservation failures hidden by the default diagnostic limit. These coding decisions are unchanged from the full evaluation.

`reference.log` preserves original stdout/stderr payload bytes; surrounding headers identify file paths and lengths. Historical paths identify provenance and are not dependencies. Repeated full replay logs, generated candidate/response copies, long reports and environment inventories are omitted. No tool binaries are bundled.

Workbook SHA-256: `54f9f3e06063bb90eccccdad9ce0fe4c2a3ce303c3528bf8761d1c933fcc334e`.
Source archive: `dafny_invarant_reproduction_pack.zip`; SHA-256 `56b25d534a5208fd865fe2154a3c47b487a7fd5ee6d4f5f6cc80757650c88f14`. The Downloads and Temp6 archives are byte-identical. CSV call signs are retained only for provenance; no participant comparison is intended.
