import C1

-- Exactly one diagnostic demonstration, deliberately separate from T0.
def main : IO Unit := do
  let actual := C1 [1,2,2,3] 2
  if actual != some 1 then
    throw (IO.userError s!"Diagnostic failed: {actual}")
  IO.println "Diagnostic PASS: [1,2,2,3], 2 -> some 1"
