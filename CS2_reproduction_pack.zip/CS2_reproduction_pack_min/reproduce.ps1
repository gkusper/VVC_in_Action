param([string]$LeanExe = '', [string]$OutputDirectory = '')
$ErrorActionPreference = 'Stop'
if (!$LeanExe) { $LeanExe = (Get-Command lean -ErrorAction Stop).Source }
$LeanExe = (Resolve-Path -LiteralPath $LeanExe).Path
if (!$OutputDirectory) { $OutputDirectory = Join-Path $PSScriptRoot ('replay/' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffffffZ')) }
New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null
$OutputDirectory = (Resolve-Path -LiteralPath $OutputDirectory).Path
$encoding = [Text.UTF8Encoding]::new($false)
$log = Join-Path $OutputDirectory 'verification.log'
$sources = @'
[
  {
    "name": "C0.lean",
    "sha256": "a95c74bba178d3e58d949d907f223537bf4b8f02c04e1d39e3b46b44123ea759"
  },
  {
    "name": "L0.lean",
    "sha256": "a44c2f0c2e65e36b51fde82a5b5dc83f8c25d1773360524175a53640e4a5260e"
  },
  {
    "name": "T0.lean",
    "sha256": "6faa579674259b7d507c94424ccdf8566d8673f920f977f9fc846cce67380ce4"
  },
  {
    "name": "TestsC0.lean",
    "sha256": "1b0b50adb9a7abbdd9d47f60e2f8945a7724b8b72d62b516d7b263c5bbfcb733"
  },
  {
    "name": "Counterexample.lean",
    "sha256": "7324203379bfc7e3ad2998cab266a95ed6a0a7fe935f3f82282cf421dcbb4687"
  },
  {
    "name": "C1.lean",
    "sha256": "218341139fbca25a949f40e4a63e9f41100c88af3af812064b84743d790c613d"
  },
  {
    "name": "Correctness.lean",
    "sha256": "3436d9fb03ccc7ef511446f546a076a89bd4912682aaeb58579e5edb6b177578"
  },
  {
    "name": "Diagnostic.lean",
    "sha256": "9c9ab2470981e3c15810f777501fb018d11a56f317fcb91dfe7e24d1af503e66"
  },
  {
    "name": "TestsC1.lean",
    "sha256": "a0cb1efd633ac9e56641d5916c8b6afce6cd9afcc5cf03fd306b80f5758a9c49"
  }
]
'@ | ConvertFrom-Json
$steps = @'
[
  {
    "arguments": [
      "-o",
      "C0.olean",
      "C0.lean"
    ],
    "tests": false,
    "contains": []
  },
  {
    "arguments": [
      "-o",
      "T0.olean",
      "T0.lean"
    ],
    "tests": false,
    "contains": []
  },
  {
    "arguments": [
      "-o",
      "L0.olean",
      "L0.lean"
    ],
    "tests": false,
    "contains": []
  },
  {
    "arguments": [
      "-o",
      "C1.olean",
      "C1.lean"
    ],
    "tests": false,
    "contains": []
  },
  {
    "arguments": [
      "--run",
      "TestsC0.lean"
    ],
    "tests": true,
    "contains": []
  },
  {
    "arguments": [
      "-o",
      "Counterexample.olean",
      "Counterexample.lean"
    ],
    "tests": false,
    "contains": [
      "c0_counterexample",
      "c0_not_universally_correct"
    ]
  },
  {
    "arguments": [
      "--run",
      "TestsC1.lean"
    ],
    "tests": true,
    "contains": []
  },
  {
    "arguments": [
      "--run",
      "Diagnostic.lean"
    ],
    "tests": false,
    "contains": [
      "Diagnostic PASS:"
    ]
  },
  {
    "arguments": [
      "-o",
      "Correctness.olean",
      "Correctness.lean"
    ],
    "tests": false,
    "contains": [
      "c1_universally_correct"
    ]
  }
]
'@ | ConvertFrom-Json
foreach ($source in $sources) {
  $path = Join-Path $PSScriptRoot $source.name
  if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $source.sha256) { throw "Source hash differs: $($source.name)" }
  Copy-Item -LiteralPath $path -Destination $OutputDirectory
}
function Invoke-Lean([string[]]$Arguments) {
  $info = [Diagnostics.ProcessStartInfo]::new()
  $info.FileName = $LeanExe
  $info.WorkingDirectory = $OutputDirectory
  $info.UseShellExecute = $false
  $info.CreateNoWindow = $true
  $info.RedirectStandardOutput = $true
  $info.RedirectStandardError = $true
  foreach ($item in $Arguments) { $info.ArgumentList.Add($item) }
  $process = [Diagnostics.Process]::new()
  $process.StartInfo = $info
  if (!$process.Start()) { throw 'Cannot start Lean' }
  $outTask = $process.StandardOutput.ReadToEndAsync()
  $errTask = $process.StandardError.ReadToEndAsync()
  $process.WaitForExit()
  $stdout = $outTask.GetAwaiter().GetResult()
  $stderr = $errTask.GetAwaiter().GetResult()
  $code = $process.ExitCode
  $process.Dispose()
  [IO.File]::AppendAllText($log, "`nCOMMAND: $LeanExe $($Arguments -join ' ')`nSTDOUT:`n$stdout`nSTDERR:`n$stderr`nEXIT: $code`n", $encoding)
  [Console]::Out.Write($stdout)
  [Console]::Error.Write($stderr)
  if ($code -ne 0 -or $stdout -match 'sorryAx|error:') { throw 'Lean check failed; see verification.log' }
  return $stdout
}
$savedLeanPath = $env:LEAN_PATH
$env:LEAN_PATH = $OutputDirectory
try {
  $version = Invoke-Lean @('--version')
  if ($version -notmatch 'version 4\.34\.1,' -or $version -notmatch '5045d0056413266e57c625dcd7c365b10e377c52') { throw 'Expected recorded Lean 4.34.1 commit' }
  foreach ($step in $steps) {
    $result = Invoke-Lean $step.arguments
    if ($step.tests -and (($result -split '\r?\n' | Where-Object { $_ -match '^PASS:' }).Count -ne 7 -or $result -notmatch '7/7 tests passed')) { throw 'Expected seven passing tests' }
    foreach ($expected in $step.contains) { if (!$result.Contains($expected)) { throw "Missing result: $expected" } }
  }
  [IO.File]::AppendAllText($log, "`nREPRODUCTION: PASS`n", $encoding)
  Write-Host "REPRODUCTION: PASS ($OutputDirectory)"
} finally { $env:LEAN_PATH = $savedLeanPath }
