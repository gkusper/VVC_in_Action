# CS2 minimal reproduction package

Requires Lean 4.34.1 (commit 5045d0056413266e57c625dcd7c365b10e377c52), its bundled Std library, and PowerShell 7. No Mathlib or package download is required.

```powershell
pwsh -NoProfile -File ./reproduce.ps1 -LeanExe /path/to/lean
```

If Lean is on PATH, omit `-LeanExe`. The script checks source hashes and version, compiles dependencies, executes the tests and checks each theorem once. It writes generated files and `verification.log` under a new `replay/` directory; `-OutputDirectory` can select another location. A nonzero process exit indicates an unexpected result. Negative theorems are expected successful Lean checks.

Fixed requirement D0: Given a finite list of integers `a` and an integer `x`, return the zero-based index of the first occurrence of `x` in `a`. If `x` does not occur in the list, return no index. The result must never refer to an invalid list position.

C0/C1 are the original and repaired implementations; L0 is the full specification; T0 is the unchanged seven-test suite. Counterexample proves the C0 violation; Correctness proves C1 for all inputs. Diagnostic is outside T0.

All Lean sources are byte-for-byte copies of the supplied full package, flattened without changing module names or contents. `reference.log` concatenates one archived execution per check, with original command metadata and unedited stdout/stderr payloads. Repeated proof runs, empty standalone files, intermediate proof attempts, duplicated frozen sources, long reports and prior-package copies are omitted. The paper explains the study design and interpretation.

Source archive: `CS2_reproduction_pack.zip`; SHA-256 `2220acbc8972a8566cdfc6ec490848018e478b8436068b66e2e78408c0ea19e7`.
